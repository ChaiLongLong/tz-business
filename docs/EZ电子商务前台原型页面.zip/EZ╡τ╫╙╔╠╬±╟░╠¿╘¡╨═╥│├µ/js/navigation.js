function to(path){
  window.location = path;
}