function validateAmount(amountComponent){
  var amount = $(amountComponent).value.strip();
  if(amount.length > 0 && isNaN(amount)){
    alert("����д���֣�");
    amountComponent.select();
  }
}