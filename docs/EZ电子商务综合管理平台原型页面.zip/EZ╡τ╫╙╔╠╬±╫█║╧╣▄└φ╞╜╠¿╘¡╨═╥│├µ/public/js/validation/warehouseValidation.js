function validate(console){
  var val = $("name").value.strip();
  if(val.length == 0){
    console.show("����ⷿ���ƣ�");
    return false;
  }
  
  return true;
}    