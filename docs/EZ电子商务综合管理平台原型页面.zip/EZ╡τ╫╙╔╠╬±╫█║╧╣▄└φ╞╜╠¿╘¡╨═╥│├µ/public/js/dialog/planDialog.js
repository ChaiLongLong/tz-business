function PlanDialog(idComponent,titleComponent,panelComponent,base){
  this.idComponent = idComponent;
  this.titleComponent = titleComponent;
  this.panelComponent = panelComponent;
  this.base = base;
}

PlanDialog.prototype.show = function(popControl){
  var params = {searchType: 'newSearch'};
  var panelComponent = this.panelComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/plan.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
        var pos = getPosition(popControl);
        panelComponent.style.left = pos.x - 200 + "px";
        panelComponent.style.top = (pos.y + 10 + popControl.offsetHeight) + "px";
        panelComponent.style.display = "block";
      },
      parameters: {searchType: 'newSearch'},
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  ); 
}

PlanDialog.prototype.gotoPage = function(pageNo){
  var panelComponent = this.panelComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/plan.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
      },
      parameters: {pageNo: pageNo},
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  ); 
}

PlanDialog.prototype.setValues = function (id, title){
  this.idComponent.value = id;
  this.titleComponent.value = title;
  this.hide();
}

PlanDialog.prototype.hide = function(){      
  this.panelComponent.style.display = "none";
}

PlanDialog.prototype.clearValues = function (){
  this.idComponent.value = "";
  this.titleComponent.value = "";
  this.hide();
}