function DepartmentDialog(idComponent,nameComponent,panelComponent,base,codeComponent){
  this.idComponent = idComponent;
  this.nameComponent = nameComponent;
  this.panelComponent = panelComponent;
  this.base = base;
  this.codeComponent = codeComponent;
}

DepartmentDialog.prototype.show = function(popControl){
  var params = {searchType: 'newSearch'};
  var panelComponent = this.panelComponent;
  var base = this.base;
  panelComponent.innerHTML = 
  "<table>"+
  "<tr><td><a href=\"javascript:departmentDialog.setValues(1,'aaaaa','aaaaaa');\">aaaaaa</a></td><td>bbbbbb</td></tr>"+
  "<tr><td><a href=''>cccccc</a></td><td>dddddd</td></tr>"+
  "<tr><td><a href=''>eeeeee</a></td><td>ffffff</td></tr>"+
  "</table>";
  var pos = getPosition(popControl);
  panelComponent.style.left = pos.x - 100 + "px";
  panelComponent.style.top = (pos.y + 10 + popControl.offsetHeight) + "px";
  panelComponent.style.display = "block";

  /*AJax����
  new Ajax.Request(base + '/ctrl/dialog/department.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
        var pos = getPosition(popControl);
        panelComponent.style.left = pos.x - 100 + "px";
        panelComponent.style.top = (pos.y + 10 + popControl.offsetHeight) + "px";
        panelComponent.style.display = "block";
      },
      parameters: params,
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  );
  */
}

DepartmentDialog.prototype.gotoPage = function(pageNo){
  var panelComponent = this.panelComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/department.dialog?' + new Date().getTime(), 
  {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
      },
      parameters: {pageNo: pageNo},
      onFailure: function(transport){
       alert("error:" + transport.status);
      }
    }
  ); 
}

DepartmentDialog.prototype.setValues = function (id, name,code){
  this.idComponent.value = id;
  this.nameComponent.value = name;
  if(this.codeComponent && code){
    this.codeComponent.value = code;
  }
  this.hide();
}

DepartmentDialog.prototype.hide = function(){      
  this.panelComponent.style.display = "none";
}

DepartmentDialog.prototype.clearValues = function (){
  this.idComponent.value = "";
  this.nameComponent.value = "";
  if(this.codeComponent){
    this.codeComponent.value = "";
  }
  this.hide();
}