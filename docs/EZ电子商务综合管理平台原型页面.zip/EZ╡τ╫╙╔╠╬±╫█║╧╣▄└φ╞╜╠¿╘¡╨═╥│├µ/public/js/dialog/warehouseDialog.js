function WarehouseDialog(idComponent,nameComponent,panelComponent,base){
  this.idComponent = idComponent;
  this.nameComponent = nameComponent;
  this.panelComponent = panelComponent;
  this.base = base;
}

WarehouseDialog.prototype.show = function(popControl){
  var params = {searchType: 'newSearch'};
  var panelComponent = this.panelComponent;
  var base = this.base;  
  new Ajax.Request(base + '/ctrl/dialog/warehouse.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
        var pos = getPosition(popControl);
        panelComponent.style.left = pos.x - 150 + "px";
        panelComponent.style.top = (pos.y + 10 + popControl.offsetHeight) + "px";
        panelComponent.style.display = "block";
      },
      parameters: {searchType: 'newSearch'},
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  ); 
}

WarehouseDialog.prototype.gotoPage = function(pageNo){
  var panelComponent = this.panelComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/warehouse.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
      },
      parameters: {pageNo: pageNo},
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  ); 
}

WarehouseDialog.prototype.setValues = function (id, name){
  this.idComponent.value = id;
  this.nameComponent.value = name;
  this.hide();
}

WarehouseDialog.prototype.hide = function(){      
  this.panelComponent.style.display = "none";
}

WarehouseDialog.prototype.clearValues = function (){
  this.idComponent.value = "";
  this.nameComponent.value = "";
  this.hide();
}