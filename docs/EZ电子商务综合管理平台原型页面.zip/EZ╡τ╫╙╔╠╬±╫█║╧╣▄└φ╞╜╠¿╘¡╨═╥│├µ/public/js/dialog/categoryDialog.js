function CategoryDialog(idComponent,nameComponent,panelComponent,base,codeComponent){
  this.idComponent = idComponent;
  this.nameComponent = nameComponent;
  this.panelComponent = panelComponent;
  this.codeComponent = codeComponent;
  this.base = base;
}

CategoryDialog.prototype.show = function(popControl){
  var params = {searchType: 'newSearch'};
  var panelComponent = this.panelComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/category.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
        var pos = getPosition(popControl);
        panelComponent.style.left = pos.x - 200 + "px";
        panelComponent.style.top = (pos.y + popControl.offsetHeight + 10) + "px";
        panelComponent.style.display = "block";
      },
      parameters: params,
      onFailure: function(){
        alert("error!");
      }
    }
  ); 
}

CategoryDialog.prototype.gotoPage = function(pageNo){
  var panelComponent = this.panelComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/category.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        panelComponent.innerHTML = responseText;
      },
      parameters: {pageNo: pageNo},
      onFailure: function(){
        alert("error!");
      }
    }
  ); 
}

CategoryDialog.prototype.setValues = function (id, name,code){
  this.idComponent.value = id;
  this.nameComponent.value = name;
  if(this.codeComponent && code){
    this.codeComponent.value = code;
  }
  this.hide();
}

CategoryDialog.prototype.hide = function(){      
  this.panelComponent.style.display = "none";
}

CategoryDialog.prototype.clearValues = function (){
  this.idComponent.value = "";
  this.nameComponent.value = "";
  if(this.codeComponent){
    this.codeComponent.value = "";
  }
  this.hide();
}