function SupplierDialog(idComponent,nameComponent,panelComponent,responseComponent,base){
  this.idComponent = idComponent;
  this.nameComponent = nameComponent;
  this.panelComponent = panelComponent;
  this.responseComponent = responseComponent;
  this.base = base;
}

SupplierDialog.prototype.show = function(popControl){
  var params = {searchType: 'newSearch'};
  var panelComponent = this.panelComponent;
  var responseComponent = this.responseComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/supplier.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        responseComponent.innerHTML = responseText;
        var pos = getPosition(popControl);
        panelComponent.style.left = pos.x - 300 + "px";
        panelComponent.style.top = (pos.y + popControl.offsetHeight) + "px";
        panelComponent.style.display = "block";
      },
      parameters: params,
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  ); 
}

SupplierDialog.prototype.changeProvince = function(province,city){
  initCity(city,province.value);
  this.changeCity(province,city);
}

SupplierDialog.prototype.changeCity = function(province, city){
  var params = {
    searchType: 'newSearch',
    province: province.value,
    city: city.value
  };
  var responseComponent = this.responseComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/supplier.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        responseComponent.innerHTML = responseText;
      },
      parameters: params,
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  );       
}

SupplierDialog.prototype.gotoPage = function(pageNo){
  var responseComponent = this.responseComponent;
  var base = this.base;
  new Ajax.Request(base + '/ctrl/dialog/supplier.dialog?' + new Date().getTime(), 
    {
      method:'get',
      onSuccess: function(transport){
        var responseText = transport.responseText;
        responseComponent.innerHTML = responseText;
      },
      parameters: {pageNo: pageNo},
      onFailure: function(transport){
        alert("error:" + transport.status);
      }
    }
  ); 
}

SupplierDialog.prototype.setValues = function (id, name){
  this.idComponent.value = id;
  this.nameComponent.value = name;
  this.hide();
}

SupplierDialog.prototype.hide = function(){      
  this.panelComponent.style.display = "none";
}
    
