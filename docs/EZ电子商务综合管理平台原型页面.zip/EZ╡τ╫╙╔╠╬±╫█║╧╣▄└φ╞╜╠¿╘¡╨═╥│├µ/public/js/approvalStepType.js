var approvalStepTypeCodes = ['1','2'];
var approvalStepTypeNames = ['ȫ��ͨ��','��һͨ��'];

function initApprovalStepTypes(comp,defaultValue){
  init(comp, approvalStepTypeCodes,approvalStepTypeNames,defaultValue);
}

function getApprovalStepTypeName(code){
  return getName(code, approvalStepTypeCodes, approvalStepTypeNames);
}