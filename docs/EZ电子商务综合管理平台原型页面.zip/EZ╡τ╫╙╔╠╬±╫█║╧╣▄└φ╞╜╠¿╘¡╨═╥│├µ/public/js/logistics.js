function init(comp,codes,names,defaultValue){
  for(var i =  0; i < codes.length; i++){
    var opt = new Option(names[i], codes[i]);
    comp.options[comp.options.length] = opt;
    if(defaultValue){
      if(defaultValue == codes[i]){
        opt.selected = true;
      }
    }
  }
}

function getName(code,codes,names){
  var name = "";
  for(var i =  0; i < codes.length; i++){
    if(codes[i] == code){
      name = names[i];
    }
  }  
  return name;
}

function toTop(url){
  if (window != top){
    top.location.href = url; 
  }
}
    
function to(url){
	window.location.href=url;
}

function back(){
	history.back();
}

function getPosition(e){
   var x = e.offsetLeft;
   var y = e.offsetTop;
   while(e = e.offsetParent){
     x += e.offsetLeft;
     y += e.offsetTop;
  }
  return {"x": x, "y": y};
}

function Console(panel){
  this.panel = panel;
}

Console.prototype.show = function(message){
  this.panel.innerHTML = message;
  this.panel.style.display = "block";
}

Console.prototype.hide = function(){
  this.panel.innerHTML = "";
  this.panel.style.display = "none";
} 