var saleStatusCodes = ['Y','N'];
var saleStatusNames = ['������','��ͣ��'];

function initSaleStatus(comp,defaultValue){
  init(comp, saleStatusCodes,saleStatusNames,defaultValue);
}

function getSaleStatusName(code){
  return getName(code, saleStatusCodes, saleStatusNames);
}