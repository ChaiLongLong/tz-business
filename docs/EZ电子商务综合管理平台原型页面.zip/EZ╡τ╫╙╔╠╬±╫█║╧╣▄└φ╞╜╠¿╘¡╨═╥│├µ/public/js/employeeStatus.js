var employeeStatusCodes = ['1','0'];
var employeeStatusNames = ['��ְ','����ְ'];

function initEmployeeStatus(comp,defaultValue){
  init(comp, employeeStatusCodes,employeeStatusNames,defaultValue);
}

function getEmployeeStatusName(code){
  return getName(code, employeeStatusCodes, employeeStatusNames);
}