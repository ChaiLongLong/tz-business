function initRoles(comp, roleCodes, roleNames, defaultValue){
  var codeAry = roleCodes.split(",");
  var nameAry = roleNames.split(",");
  init(comp, codeAry, nameAry, defaultValue);
}

function getRoleName(roleCodes, roleNames, code){
  var codeAry = roleCodes.split(",");
  var nameAry = roleNames.split(",");
  for(var i = 0; i < codeAry.length; i++){
    if(codeAry[i] == code){
      return nameAry[i];
    }
  }
  
  return "";
}