var functionTypeCodes = ["v", "c"];
var functionTypeNames = ["��ͼ", "����"];

function initFunctionTypes(comp,defaultValue){
  init(comp, functionTypeCodes,functionTypeNames,defaultValue);
}

function getFunctionTypeName(code){
  return getName(code, functionTypeCodes, functionTypeNames);
}