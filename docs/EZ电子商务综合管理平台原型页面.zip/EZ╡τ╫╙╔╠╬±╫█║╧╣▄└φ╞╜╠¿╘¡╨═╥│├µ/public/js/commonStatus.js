var statusCodes = ['1','0'];
var statusNames = ['ʹ����','��ͣ��'];

function initStatus(comp,defaultValue){
  for(var i =  0; i < statusCodes.length; i++){
    var opt = new Option(statusNames[i], statusCodes[i]);
    comp.options[comp.options.length] = opt;
    if(defaultValue){
      if(defaultValue == statusCodes[i]){
        opt.selected = true;
      }
    }
  }
}

function getStatusName(code){
  var name = "";
  for(var i =  0; i < statusCodes.length; i++){
    if(statusCodes[i] == code){
      name = statusNames[i];
    }
  }
  
  return name;
}